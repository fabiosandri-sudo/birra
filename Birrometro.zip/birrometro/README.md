# 🍺 Birrometro

App Android che riconosce i pagamenti fatti con Google Wallet in un locale scelto
(es. "Urban Climbing"), li trasforma in birre (450 ml ciascuna) e li mostra in un
widget a forma di calice.

## Cosa fa

- **Riconoscimento automatico**: quando arriva la notifica di Wallet con il nome del locale
  - fino a 7,50 € → +1 birra automatica;
  - sopra 7,50 € (es. birra + panino) → una notifica chiede "quante birre?" (0, 1, 2, 3).
- **Conferma con "Annulla"** dopo ogni birra registrata.
- **Aggiunta manuale**: nell'app (scegli quante birre) e con il pulsante **+1** sul widget.
- **Contatore annuale** con vista del mese, del mese scorso e grafico mese per mese.
- **Calorie** (predefinito 43 kcal per 100 ml, modificabile).
- **Stato del giorno** con faccina: 😇 Sobrio → 🙂 Allegro → 😄 Brillo → 🥴 Alticcio → 🤪 Cotto → 🛋️ Sciolto.
  È solo un gioco e non misura il tasso alcolemico: dalla prima birra compare "🚗❌ Oggi niente guida".
- **Widget**: tocca il calice per passare da mese ad anno, tocca il testo per aprire l'app.
- **Storico**: puoi impostare a mano il totale dei mesi passati ed esportare il registro in CSV.

Tutti i dati restano sul telefono. L'app non usa Internet.

## Come ottenere l'APK

### Metodo 1: GitHub (senza installare niente sul computer)
1. Crea un account su github.com e un nuovo repository (anche privato).
2. Carica tutti i file di questa cartella (pulsante "Add file → Upload files", trascinando la cartella).
3. Vai nella scheda **Actions**: parte da solo "Crea APK" (circa 3–5 minuti).
4. A fine lavoro apri l'esecuzione e scarica **Birrometro-apk**: dentro c'è `app-debug.apk`.

### Metodo 2: Android Studio
1. Apri la cartella con Android Studio.
2. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
3. Il file è in `app/build/outputs/apk/debug/app-debug.apk`.

## Installazione (anche per gli amici)
1. Manda il file `app-debug.apk` (WhatsApp, Telegram, Drive...).
2. Aprilo sul telefono e consenti "Installa app sconosciute" quando richiesto.
3. Apri **Birrometro** e:
   - consenti le notifiche;
   - tocca **Attiva lettura notifiche** e abilita Birrometro.
     Su Android 13+ potrebbe servire prima: Impostazioni → App → Birrometro → ⋮ → "Consenti impostazioni con restrizioni";
   - in **Impostazioni** scrivi il nome del tuo locale (più locali separati da virgola), la soglia e i ml.
4. Aggiungi il widget: tieni premuto sulla schermata Home → Widget → Birrometro → "Calice di birra".

Se un amico paga con l'app della banca invece che con Google Wallet, basta togliere la spunta
"Leggi solo le notifiche di Google Wallet".
