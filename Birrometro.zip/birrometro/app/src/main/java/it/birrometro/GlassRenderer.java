package it.birrometro;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;

/** Disegna un calice di birra riempito dalla frazione 0..1. Usato da app e widget. */
public final class GlassRenderer {

    private GlassRenderer() {}

    public static Bitmap render(int w, int h, float fill) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        draw(new Canvas(bmp), w, h, fill);
        return bmp;
    }

    public static void draw(Canvas c, float w, float h, float fill) {
        fill = Math.max(0f, Math.min(1f, fill));

        float top = h * 0.06f;
        float left = w * 0.16f;
        float right = w * 0.84f;
        float bowlBottom = h * 0.62f;
        float cx = w * 0.5f;

        // Coppa del calice
        Path bowl = new Path();
        bowl.moveTo(left, top);
        bowl.lineTo(right, top);
        bowl.cubicTo(right, h * 0.42f, w * 0.70f, bowlBottom - h * 0.02f, cx, bowlBottom);
        bowl.cubicTo(w * 0.30f, bowlBottom - h * 0.02f, left, h * 0.42f, left, top);
        bowl.close();

        Paint glass = new Paint(Paint.ANTI_ALIAS_FLAG);
        glass.setStyle(Paint.Style.FILL);
        glass.setColor(0x22FFFFFF);
        c.drawPath(bowl, glass);

        // Birra + schiuma, ritagliate dentro la coppa
        if (fill > 0f) {
            float beerTop = bowlBottom - fill * (bowlBottom - top);
            c.save();
            c.clipPath(bowl);
            Paint beer = new Paint(Paint.ANTI_ALIAS_FLAG);
            beer.setShader(new LinearGradient(0, beerTop, 0, bowlBottom,
                    0xFFFFC233, 0xFFE08A00, Shader.TileMode.CLAMP));
            c.drawRect(0, beerTop, w, bowlBottom + 2, beer);

            // Bollicine
            Paint bubble = new Paint(Paint.ANTI_ALIAS_FLAG);
            bubble.setColor(0x66FFFFFF);
            float r = Math.max(1.5f, w * 0.012f);
            float[][] pts = {{0.40f, 0.85f}, {0.55f, 0.70f}, {0.47f, 0.55f}, {0.60f, 0.40f}, {0.36f, 0.30f}};
            for (float[] p : pts) {
                float y = bowlBottom - p[1] * (bowlBottom - beerTop);
                if (y > beerTop + r * 2) c.drawCircle(w * p[0], y, r, bubble);
            }

            // Schiuma
            float foamH = Math.min(h * 0.06f, (bowlBottom - beerTop) * 0.5f + h * 0.02f);
            Paint foam = new Paint(Paint.ANTI_ALIAS_FLAG);
            foam.setColor(0xFFFFF8E7);
            c.drawRect(0, beerTop - foamH * 0.6f, w, beerTop + foamH * 0.4f, foam);
            c.restore();
        }

        // Contorno, gambo e base
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(2f, w * 0.022f));
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(0xDDFFFFFF);
        c.drawPath(bowl, stroke);

        Paint solid = new Paint(Paint.ANTI_ALIAS_FLAG);
        solid.setColor(0xDDFFFFFF);
        float stemW = w * 0.035f;
        c.drawRect(cx - stemW, bowlBottom, cx + stemW, h * 0.88f, solid);
        c.drawOval(new RectF(w * 0.28f, h * 0.86f, w * 0.72f, h * 0.94f), solid);

        // Riflesso sul vetro
        Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
        shine.setStyle(Paint.Style.STROKE);
        shine.setStrokeWidth(Math.max(2f, w * 0.02f));
        shine.setStrokeCap(Paint.Cap.ROUND);
        shine.setColor(0x55FFFFFF);
        Path p = new Path();
        p.moveTo(w * 0.25f, h * 0.12f);
        p.cubicTo(w * 0.25f, h * 0.30f, w * 0.30f, h * 0.42f, w * 0.36f, h * 0.50f);
        c.drawPath(p, shine);
    }
}
