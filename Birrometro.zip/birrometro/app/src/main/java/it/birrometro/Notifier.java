package it.birrometro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

/** Notifiche dell'app: conferma "+1 birra" e domanda "quante birre?". */
public final class Notifier {

    static final String CHANNEL = "birre";
    static final int ID_CONFIRM = 1001;
    static final int ID_ASK = 1002;

    private Notifier() {}

    static void ensureChannel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Birre", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Conferme e domande sulle birre registrate");
            nm.createNotificationChannel(ch);
        }
    }

    /** "+1 birra 🍺" con il pulsante Annulla. */
    static void confirm(Context c, int ml, String merchant) {
        ensureChannel(c);
        int month = BeerStore.getCurrentMonthMl(c);
        int beers = Math.max(1, Math.round(ml / (float) Math.max(1, BeerStore.getMlPerBeer(c))));
        String title = "+" + beers + (beers == 1 ? " birra 🍺" : " birre 🍺") + " da " + merchant;
        String text = "Questo mese: " + BeerStore.liters(month) + " · anno: "
                + BeerStore.liters(BeerStore.getYearMl(c, BeerStore.currentYear()));

        Intent undo = new Intent(c, BeerActionReceiver.class).setAction(BeerActionReceiver.ACTION_UNDO);
        PendingIntent piUndo = PendingIntent.getBroadcast(c, 900, undo,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_beer)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setTimeoutAfter(6 * 60 * 60 * 1000L)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(c, R.drawable.ic_beer), "Annulla", piUndo).build())
                .build();
        post(c, ID_CONFIRM, n);
    }

    /** Importo sopra la soglia (es. birra + panino): chiede quante birre contare. */
    static void askHowMany(Context c, String merchant, String amount) {
        ensureChannel(c);
        Notification.Builder b = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_beer)
                .setContentTitle(merchant + ": " + amount)
                .setContentText("Quante birre c'erano in questo pagamento?")
                .setAutoCancel(true);
        for (int i = 0; i <= 3; i++) {
            Intent it = new Intent(c, BeerActionReceiver.class)
                    .setAction(BeerActionReceiver.ACTION_COUNT)
                    .putExtra(BeerActionReceiver.EXTRA_COUNT, i)
                    .putExtra(BeerActionReceiver.EXTRA_MERCHANT, merchant)
                    .putExtra(BeerActionReceiver.EXTRA_AMOUNT, amount);
            PendingIntent pi = PendingIntent.getBroadcast(c, 800 + i, it,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            String label = i == 0 ? "Nessuna" : String.valueOf(i);
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(c, R.drawable.ic_beer), label, pi).build());
        }
        post(c, ID_ASK, b.build());
    }

    static void cancel(Context c, int id) {
        c.getSystemService(NotificationManager.class).cancel(id);
    }

    private static void post(Context c, int id, Notification n) {
        try {
            c.getSystemService(NotificationManager.class).notify(id, n);
        } catch (SecurityException ignored) {
            // Permesso notifiche negato: la birra è comunque registrata.
        }
    }
}
