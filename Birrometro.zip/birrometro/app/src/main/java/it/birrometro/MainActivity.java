package it.birrometro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {

    private static final int BG = 0xFF121212;
    private static final int CARD = 0xFF1E1E1E;
    private static final int AMBER = 0xFFFFC233;

    private float dp;
    private TextView accessStatus, total, totalSub, moodEmoji, moodText, todayText, driveText, countText;
    private Button accessButton, viewButton;
    private GlassView glass;
    private MonthChartView chart;
    private EditText edKeywords, edThreshold, edMl, edKcal, edGoalMonth, edGoalYear, edHistMonth, edHistBeers;
    private CheckBox cbWallet;
    private int manualCount = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        Notifier.ensureChannel(this);
        setContentView(buildUi());
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        BeerStore.prefs(this).registerOnSharedPreferenceChangeListener(this);
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        BeerStore.prefs(this).unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        runOnUiThread(this::refresh);
    }

    // ---------------- interfaccia ----------------

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = vertical();
        int pad = px(16);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = text("🍺 Birrometro", 26, 0xFFFFFFFF, true);
        root.addView(title);

        // Accesso alle notifiche
        LinearLayout acc = card(root);
        accessStatus = text("", 14, 0xFFDDDDDD, false);
        acc.addView(accessStatus);
        accessButton = button("Attiva lettura notifiche", v ->
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        acc.addView(accessButton);

        // Calice e totali
        LinearLayout main = card(root);
        glass = new GlassView(this);
        main.addView(glass, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(220)));
        total = text("", 28, 0xFFFFFFFF, true);
        total.setGravity(Gravity.CENTER);
        main.addView(total);
        totalSub = text("", 14, 0xFFBBBBBB, false);
        totalSub.setGravity(Gravity.CENTER);
        main.addView(totalSub);
        viewButton = button("", v -> {
            BeerStore.toggleView(this);
            BeerWidgetProvider.updateAll(this);
            refresh();
        });
        main.addView(viewButton);

        // Stato di oggi
        LinearLayout today = card(root);
        today.addView(text("Oggi", 16, AMBER, true));
        LinearLayout row = horizontal();
        moodEmoji = text("", 44, 0xFFFFFFFF, false);
        row.addView(moodEmoji);
        LinearLayout col = vertical();
        col.setPadding(px(12), 0, 0, 0);
        moodText = text("", 18, 0xFFFFFFFF, true);
        todayText = text("", 14, 0xFFBBBBBB, false);
        driveText = text("", 14, 0xFFFF6B6B, true);
        col.addView(moodText);
        col.addView(todayText);
        col.addView(driveText);
        row.addView(col);
        today.addView(row);

        // Inserimento manuale
        LinearLayout man = card(root);
        man.addView(text("Aggiungi a mano", 16, AMBER, true));
        LinearLayout step = horizontal();
        step.setGravity(Gravity.CENTER_VERTICAL);
        step.addView(button("−", v -> { manualCount = Math.max(1, manualCount - 1); refresh(); }));
        countText = text("", 22, 0xFFFFFFFF, true);
        countText.setPadding(px(16), 0, px(16), 0);
        step.addView(countText);
        step.addView(button("+", v -> { manualCount = Math.min(20, manualCount + 1); refresh(); }));
        man.addView(step);
        LinearLayout btns = horizontal();
        btns.addView(button("Aggiungi", v -> {
            int ml = manualCount * BeerStore.getMlPerBeer(this);
            BeerStore.add(this, ml, "manuale", "");
            toast("+" + manualCount + " 🍺");
            manualCount = 1;
            refresh();
        }));
        btns.addView(button("Annulla ultima", v ->
                toast(BeerStore.undoLast(this) ? "Ultima aggiunta annullata" : "Niente da annullare")));
        man.addView(btns);

        // Grafico mensile
        LinearLayout ch = card(root);
        ch.addView(text("Litri per mese (" + BeerStore.currentYear() + ")", 16, AMBER, true));
        chart = new MonthChartView(this);
        ch.addView(chart, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(170)));

        // Impostazioni
        LinearLayout set = card(root);
        set.addView(text("Impostazioni", 16, AMBER, true));
        edKeywords = field(set, "Negozi da contare (separati da virgola)", InputType.TYPE_CLASS_TEXT);
        edThreshold = field(set, "Fino a questo importo = 1 birra automatica (€)", decimal());
        edMl = field(set, "Millilitri per birra", InputType.TYPE_CLASS_NUMBER);
        edKcal = field(set, "Calorie per 100 ml", decimal());
        edGoalMonth = field(set, "Calice pieno al mese con (litri)", decimal());
        edGoalYear = field(set, "Calice pieno all'anno con (litri)", decimal());
        cbWallet = new CheckBox(this);
        cbWallet.setText("Leggi solo le notifiche di Google Wallet");
        cbWallet.setTextColor(0xFFDDDDDD);
        set.addView(cbWallet);
        set.addView(button("Salva impostazioni", v -> saveSettings()));
        loadSettings();

        // Storico
        LinearLayout hist = card(root);
        hist.addView(text("Inserisci lo storico di un mese", 16, AMBER, true));
        hist.addView(text("Sostituisce il totale di quel mese con il numero di birre indicato.", 12, 0xFF999999, false));
        edHistMonth = field(hist, "Mese (AAAA-MM)", InputType.TYPE_CLASS_TEXT);
        edHistMonth.setText(BeerStore.currentMonthKey());
        edHistBeers = field(hist, "Numero di birre", InputType.TYPE_CLASS_NUMBER);
        hist.addView(button("Imposta mese", v -> saveHistory()));
        hist.addView(button("Esporta registro (CSV)", v -> exportLog()));

        TextView note = text("Lo stato del giorno è solo un gioco e non misura il tasso alcolemico. "
                + "Se hai bevuto, non guidare. I dati restano sul telefono.", 11, 0xFF888888, false);
        note.setPadding(0, px(8), 0, px(24));
        root.addView(note);
        return scroll;
    }

    private void refresh() {
        boolean enabled = isListenerEnabled();
        accessStatus.setText(enabled
                ? "✅ Lettura notifiche attiva: i pagamenti vengono riconosciuti."
                : "⚠️ Lettura notifiche non attiva: abilita Birrometro per riconoscere i pagamenti.");
        accessButton.setVisibility(enabled ? View.GONE : View.VISIBLE);

        boolean year = BeerStore.isYearView(this);
        int ml = year ? BeerStore.getYearMl(this, BeerStore.currentYear()) : BeerStore.getCurrentMonthMl(this);
        int goal = Math.max(1, year ? BeerStore.getGoalYear(this) : BeerStore.getGoalMonth(this));
        glass.setFill(ml / (float) goal);
        total.setText((year ? "Quest'anno " : "Questo mese ") + BeerStore.liters(ml));
        totalSub.setText(BeerStore.beers(this, ml) + " birre · " + BeerStore.kcal(this, ml) + " kcal"
                + (year ? "" : " · mese scorso " + BeerStore.liters(BeerStore.getPreviousMonthMl(this))));
        viewButton.setText(year ? "Mostra il mese" : "Mostra l'anno");

        String[] mood = BeerStore.mood(this);
        int t = BeerStore.getTodayMl(this);
        moodEmoji.setText(mood[0]);
        moodText.setText(mood[1]);
        todayText.setText(BeerStore.beers(this, t) + " birre · " + BeerStore.liters(t) + " · " + BeerStore.kcal(this, t) + " kcal");
        String warn = BeerStore.driveWarning(this);
        driveText.setText(warn);
        driveText.setVisibility(warn.isEmpty() ? View.GONE : View.VISIBLE);

        countText.setText(manualCount + " 🍺");
        chart.setValues(BeerStore.getYearMonths(this, BeerStore.currentYear()),
                Calendar.getInstance().get(Calendar.MONTH));
    }

    // ---------------- azioni ----------------

    private void loadSettings() {
        edKeywords.setText(BeerStore.getKeywords(this));
        edThreshold.setText(fmt(BeerStore.getThreshold(this)));
        edMl.setText(String.valueOf(BeerStore.getMlPerBeer(this)));
        edKcal.setText(fmt(BeerStore.getKcalPer100(this)));
        edGoalMonth.setText(fmt(BeerStore.getGoalMonth(this) / 1000f));
        edGoalYear.setText(fmt(BeerStore.getGoalYear(this) / 1000f));
        cbWallet.setChecked(BeerStore.isWalletOnly(this));
    }

    private void saveSettings() {
        try {
            int ml = Integer.parseInt(edMl.getText().toString().trim());
            if (ml <= 0) throw new NumberFormatException();
            BeerStore.prefs(this).edit()
                    .putString(BeerStore.K_KEYWORDS, edKeywords.getText().toString().trim())
                    .putFloat(BeerStore.K_THRESHOLD, num(edThreshold))
                    .putInt(BeerStore.K_ML, ml)
                    .putFloat(BeerStore.K_KCAL, num(edKcal))
                    .putInt(BeerStore.K_GOAL_MONTH, Math.max(1, Math.round(num(edGoalMonth) * 1000)))
                    .putInt(BeerStore.K_GOAL_YEAR, Math.max(1, Math.round(num(edGoalYear) * 1000)))
                    .putBoolean(BeerStore.K_WALLET_ONLY, cbWallet.isChecked())
                    .apply();
            BeerWidgetProvider.updateAll(this);
            toast("Impostazioni salvate");
        } catch (NumberFormatException e) {
            toast("Controlla i numeri inseriti");
        }
    }

    private void saveHistory() {
        String key = edHistMonth.getText().toString().trim();
        if (!key.matches("\\d{4}-(0[1-9]|1[0-2])")) {
            toast("Scrivi il mese come 2026-10");
            return;
        }
        try {
            int n = Integer.parseInt(edHistBeers.getText().toString().trim());
            BeerStore.setMonthMl(this, key, n * BeerStore.getMlPerBeer(this));
            toast(key + ": " + n + " birre");
            refresh();
        } catch (NumberFormatException e) {
            toast("Inserisci un numero di birre");
        }
    }

    private void exportLog() {
        String csv = "data;negozio;importo;ml\n" + BeerStore.getLog(this);
        Intent send = new Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, "Birrometro - registro")
                .putExtra(Intent.EXTRA_TEXT, csv);
        startActivity(Intent.createChooser(send, "Esporta registro"));
    }

    private boolean isListenerEnabled() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(getPackageName());
    }

    // ---------------- piccoli aiuti ----------------

    private int px(int v) {
        return Math.round(v * dp);
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = vertical();
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(px(16));
        c.setBackground(bg);
        c.setPadding(px(14), px(12), px(14), px(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = px(12);
        parent.addView(c, lp);
        return c;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private EditText field(LinearLayout parent, String hint, int type) {
        TextView label = text(hint, 12, 0xFF999999, false);
        label.setPadding(0, px(8), 0, 0);
        parent.addView(label);
        EditText e = new EditText(this);
        e.setInputType(type);
        e.setTextColor(0xFFFFFFFF);
        e.setSingleLine(true);
        parent.addView(e);
        return e;
    }

    private static int decimal() {
        return InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;
    }

    private static float num(EditText e) {
        return Float.parseFloat(e.getText().toString().trim().replace(',', '.'));
    }

    private static String fmt(float f) {
        return String.format(Locale.ITALY, "%.2f", f).replaceAll(",00$", "");
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
