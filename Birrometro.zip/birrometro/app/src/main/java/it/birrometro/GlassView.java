package it.birrometro;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/** Calice grande nella schermata dell'app. */
public class GlassView extends View {

    private float fill = 0f;

    public GlassView(Context c) {
        super(c);
    }

    public void setFill(float f) {
        fill = f;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float h = getHeight();
        float w = Math.min(getWidth(), h * 0.85f);
        canvas.save();
        canvas.translate((getWidth() - w) / 2f, 0);
        GlassRenderer.draw(canvas, w, h, fill);
        canvas.restore();
    }
}
