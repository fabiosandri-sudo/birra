package it.birrometro;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/**
 * Widget a calice. Tocco sul calice = cambia vista mese/anno.
 * Pulsante "+1" = aggiunge una birra a mano. Tocco sul testo = apre l'app.
 */
public class BeerWidgetProvider extends AppWidgetProvider {

    static final String ACTION_TOGGLE = "it.birrometro.TOGGLE";
    static final String ACTION_PLUS = "it.birrometro.PLUS";

    @Override
    public void onUpdate(Context c, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) mgr.updateAppWidget(id, build(c));
    }

    @Override
    public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        String a = intent.getAction();
        if (ACTION_TOGGLE.equals(a)) {
            BeerStore.toggleView(c);
            updateAll(c);
        } else if (ACTION_PLUS.equals(a)) {
            BeerStore.add(c, BeerStore.getMlPerBeer(c), "manuale (widget)", "");
        }
    }

    public static void updateAll(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, BeerWidgetProvider.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews rv = build(c);
        for (int id : ids) mgr.updateAppWidget(id, rv);
    }

    static RemoteViews build(Context c) {
        boolean year = BeerStore.isYearView(c);
        int ml = year ? BeerStore.getYearMl(c, BeerStore.currentYear()) : BeerStore.getCurrentMonthMl(c);
        int goal = Math.max(1, year ? BeerStore.getGoalYear(c) : BeerStore.getGoalMonth(c));

        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_beer);
        rv.setImageViewBitmap(R.id.widget_glass, GlassRenderer.render(240, 280, ml / (float) goal));
        rv.setTextViewText(R.id.widget_title, (year ? "Anno " : "Mese ") + BeerStore.liters(ml));
        String[] mood = BeerStore.mood(c);
        int today = BeerStore.getTodayMl(c);
        rv.setTextViewText(R.id.widget_sub, BeerStore.beers(c, ml) + " birre · " + BeerStore.kcal(c, ml) + " kcal");
        rv.setTextViewText(R.id.widget_mood, mood[0] + " " + mood[1]
                + (today > 0 ? " · oggi " + BeerStore.beers(c, today) : ""));

        rv.setOnClickPendingIntent(R.id.widget_glass, broadcast(c, ACTION_TOGGLE, 700));
        rv.setOnClickPendingIntent(R.id.widget_plus, broadcast(c, ACTION_PLUS, 701));
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent piOpen = PendingIntent.getActivity(c, 702, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        rv.setOnClickPendingIntent(R.id.widget_texts, piOpen);
        return rv;
    }

    private static PendingIntent broadcast(Context c, String action, int req) {
        Intent i = new Intent(c, BeerWidgetProvider.class).setAction(action);
        return PendingIntent.getBroadcast(c, req, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }
}
