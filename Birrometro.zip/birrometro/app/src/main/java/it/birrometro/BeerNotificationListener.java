package it.birrometro;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Riceve tutte le notifiche del telefono, ma considera solo quelle di pagamento
 * che contengono uno dei negozi impostati (es. "Urban Climbing").
 */
public class BeerNotificationListener extends NotificationListenerService {

    /** Pacchetto dell'app Google Wallet. */
    public static final String WALLET_PACKAGE = "com.google.android.apps.walletnfcrel";
    public static final String GMS_PACKAGE = "com.google.android.gms";

    /** Primo importo con due decimali: "7,50", "12.50", "1.234,56". */
    private static final Pattern AMOUNT = Pattern.compile("(\\d{1,3}(?:[.\\s]\\d{3})*|\\d+)[,.](\\d{2})(?!\\d)");

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Exception ignored) {
            // Una notifica strana non deve mai far chiudere il servizio.
        }
    }

    private void handle(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals(getPackageName())) return;
        // Su alcuni telefoni le notifiche di pagamento arrivano da Google Play Services.
        if (BeerStore.isWalletOnly(this) && !pkg.equals(WALLET_PACKAGE) && !pkg.equals(GMS_PACKAGE)) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        String text = collectText(n.extras);
        if (text.isEmpty()) return;

        String merchant = matchMerchant(text, BeerStore.getKeywords(this));
        if (merchant == null) return;

        Double amount = parseAmount(text);
        if (amount == null) return;

        String id = sbn.getKey() + "|" + amount;
        if (BeerStore.isDuplicate(this, id)) return;

        String amountStr = String.format(Locale.ITALY, "%.2f €", amount);
        if (amount <= BeerStore.getThreshold(this) + 0.001) {
            int ml = BeerStore.getMlPerBeer(this);
            BeerStore.add(this, ml, merchant, amountStr);
            Notifier.confirm(this, ml, merchant);
        } else {
            Notifier.askHowMany(this, merchant, amountStr);
        }
    }

    private static String collectText(Bundle e) {
        StringBuilder sb = new StringBuilder();
        String[] keys = {
                Notification.EXTRA_TITLE, Notification.EXTRA_TEXT, Notification.EXTRA_BIG_TEXT,
                Notification.EXTRA_SUB_TEXT, Notification.EXTRA_INFO_TEXT, Notification.EXTRA_SUMMARY_TEXT
        };
        for (String k : keys) {
            CharSequence cs = e.getCharSequence(k);
            if (cs != null && cs.length() > 0) sb.append(cs).append(" \n ");
        }
        CharSequence[] lines = e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null) for (CharSequence l : lines) if (l != null) sb.append(l).append(" \n ");
        return sb.toString();
    }

    /** Restituisce la parola chiave trovata (con le maiuscole come l'ha scritta l'utente). */
    static String matchMerchant(String text, String keywords) {
        if (keywords == null) return null;
        String low = text.toLowerCase(Locale.ROOT);
        for (String k : keywords.split(",")) {
            String kw = k.trim();
            if (!kw.isEmpty() && low.contains(kw.toLowerCase(Locale.ROOT))) return kw;
        }
        return null;
    }

    static Double parseAmount(String text) {
        Matcher m = AMOUNT.matcher(text);
        if (!m.find()) return null;
        String intPart = m.group(1).replaceAll("[.\\s]", "");
        try {
            return Double.parseDouble(intPart + "." + m.group(2));
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
