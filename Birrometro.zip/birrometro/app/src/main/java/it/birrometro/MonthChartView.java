package it.birrometro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import java.util.Locale;

/** Grafico a barre: litri per mese dell'anno in corso. */
public class MonthChartView extends View {

    private static final String[] LABELS = {"G", "F", "M", "A", "M", "G", "L", "A", "S", "O", "N", "D"};
    private int[] values = new int[12];
    private int current = -1;
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barNow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint value = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);

    public MonthChartView(Context c) {
        super(c);
        float d = getResources().getDisplayMetrics().density;
        bar.setColor(0xFFB8860B);
        barNow.setColor(0xFFFFC233);
        label.setColor(0xFFBBBBBB);
        label.setTextSize(12 * d);
        label.setTextAlign(Paint.Align.CENTER);
        value.setColor(0xFFEEEEEE);
        value.setTextSize(10 * d);
        value.setTextAlign(Paint.Align.CENTER);
        grid.setColor(0x33FFFFFF);
        grid.setStrokeWidth(d);
    }

    public void setValues(int[] v, int currentMonthIndex) {
        values = v;
        current = currentMonthIndex;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float d = getResources().getDisplayMetrics().density;
        float w = getWidth(), h = getHeight();
        float bottom = h - 20 * d, top = 18 * d;
        int max = 1;
        for (int v : values) max = Math.max(max, v);
        c.drawLine(0, bottom, w, bottom, grid);
        float slot = w / 12f;
        for (int i = 0; i < 12; i++) {
            float x = slot * i + slot / 2f;
            float bh = (bottom - top) * values[i] / (float) max;
            float bw = slot * 0.55f;
            if (values[i] > 0) {
                c.drawRect(x - bw / 2, bottom - bh, x + bw / 2, bottom, i == current ? barNow : bar);
                c.drawText(String.format(Locale.ITALY, "%.1f", values[i] / 1000.0), x, bottom - bh - 4 * d, value);
            }
            c.drawText(LABELS[i], x, h - 4 * d, label);
        }
    }
}
