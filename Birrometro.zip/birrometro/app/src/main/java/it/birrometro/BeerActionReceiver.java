package it.birrometro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Gestisce i pulsanti delle notifiche. */
public class BeerActionReceiver extends BroadcastReceiver {

    static final String ACTION_COUNT = "it.birrometro.COUNT";
    static final String ACTION_UNDO = "it.birrometro.UNDO";
    static final String EXTRA_COUNT = "count";
    static final String EXTRA_MERCHANT = "merchant";
    static final String EXTRA_AMOUNT = "amount";

    @Override
    public void onReceive(Context c, Intent intent) {
        String action = intent.getAction();
        if (ACTION_COUNT.equals(action)) {
            Notifier.cancel(c, Notifier.ID_ASK);
            int count = intent.getIntExtra(EXTRA_COUNT, 0);
            if (count > 0) {
                int ml = count * BeerStore.getMlPerBeer(c);
                String merchant = intent.getStringExtra(EXTRA_MERCHANT);
                BeerStore.add(c, ml, merchant, intent.getStringExtra(EXTRA_AMOUNT));
                Notifier.confirm(c, ml, merchant == null ? "" : merchant);
            }
        } else if (ACTION_UNDO.equals(action)) {
            Notifier.cancel(c, Notifier.ID_CONFIRM);
            BeerStore.undoLast(c);
        }
    }
}
