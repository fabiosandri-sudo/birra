package it.birrometro;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Archivio locale: millilitri per mese (chiave "m_AAAA-MM"), registro delle birre
 * e impostazioni. Tutto resta sul telefono, nessun dato va in rete.
 */
public final class BeerStore {

    private static final String PREFS = "birrometro";

    // Impostazioni e valori predefiniti
    public static final String K_KEYWORDS = "keywords";       // negozi, separati da virgola
    public static final String K_THRESHOLD = "threshold";     // fino a questo importo = 1 birra automatica
    public static final String K_ML = "ml_per_beer";          // ml per birra
    public static final String K_WALLET_ONLY = "wallet_only"; // solo notifiche di Google Wallet
    public static final String K_GOAL_MONTH = "goal_month_ml";
    public static final String K_GOAL_YEAR = "goal_year_ml";
    public static final String K_VIEW = "widget_view";        // "mese" o "anno"
    public static final String K_KCAL = "kcal_per_100ml";     // calorie per 100 ml
    public static final float DEF_KCAL = 43f;                  // birra chiara media

    public static final String DEF_KEYWORDS = "Urban Climbing";
    public static final float DEF_THRESHOLD = 7.50f;
    public static final int DEF_ML = 450;
    public static final int DEF_GOAL_MONTH = 5000;
    public static final int DEF_GOAL_YEAR = 60000;

    private static final String K_LOG = "log";
    private static final String K_LAST_ML = "last_ml";
    private static final String K_LAST_MONTH = "last_month";
    private static final String K_LAST_DAY = "last_day";
    private static final String K_LAST_NOTIF = "last_notif";
    private static final String K_LAST_NOTIF_TIME = "last_notif_time";

    private BeerStore() {}

    public static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ---------- chiavi dei mesi ----------

    public static String monthKey(Calendar cal) {
        return String.format(Locale.ROOT, "%04d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
    }

    public static String currentMonthKey() {
        return monthKey(Calendar.getInstance());
    }

    public static String previousMonthKey() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        return monthKey(cal);
    }

    public static int currentYear() {
        return Calendar.getInstance().get(Calendar.YEAR);
    }

    public static String todayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date());
    }

    public static int getTodayMl(Context c) {
        return prefs(c).getInt("d_" + todayKey(), 0);
    }

    // ---------- letture ----------

    public static int getMonthMl(Context c, String key) {
        return prefs(c).getInt("m_" + key, 0);
    }

    public static int getCurrentMonthMl(Context c) {
        return getMonthMl(c, currentMonthKey());
    }

    public static int getPreviousMonthMl(Context c) {
        return getMonthMl(c, previousMonthKey());
    }

    /** ml per ciascun mese dell'anno (indice 0 = gennaio). */
    public static int[] getYearMonths(Context c, int year) {
        int[] out = new int[12];
        for (int m = 0; m < 12; m++) {
            out[m] = getMonthMl(c, String.format(Locale.ROOT, "%04d-%02d", year, m + 1));
        }
        return out;
    }

    public static int getYearMl(Context c, int year) {
        int sum = 0;
        for (int v : getYearMonths(c, year)) sum += v;
        return sum;
    }

    // ---------- scritture ----------

    /** Aggiunge ml al mese corrente, li annota nel registro e aggiorna il widget. */
    public static void add(Context c, int ml, String source, String amount) {
        if (ml == 0) return;
        String key = currentMonthKey();
        String day = todayKey();
        SharedPreferences p = prefs(c);
        int now = Math.max(0, p.getInt("m_" + key, 0) + ml);
        int today = Math.max(0, p.getInt("d_" + day, 0) + ml);
        String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT).format(new Date());
        String line = stamp + ";" + clean(source) + ";" + clean(amount) + ";" + ml;
        String log = p.getString(K_LOG, "");
        p.edit()
                .putInt("m_" + key, now)
                .putInt("d_" + day, today)
                .putInt(K_LAST_ML, ml)
                .putString(K_LAST_MONTH, key)
                .putString(K_LAST_DAY, day)
                .putString(K_LOG, log.isEmpty() ? line : log + "\n" + line)
                .apply();
        BeerWidgetProvider.updateAll(c);
    }

    /** Annulla l'ultima aggiunta (una sola volta). */
    public static boolean undoLast(Context c) {
        SharedPreferences p = prefs(c);
        int ml = p.getInt(K_LAST_ML, 0);
        String key = p.getString(K_LAST_MONTH, null);
        if (ml == 0 || key == null) return false;
        int now = Math.max(0, p.getInt("m_" + key, 0) - ml);
        String day = p.getString(K_LAST_DAY, todayKey());
        int today = Math.max(0, p.getInt("d_" + day, 0) - ml);
        String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT).format(new Date());
        String log = p.getString(K_LOG, "");
        String line = stamp + ";annullata;;" + (-ml);
        p.edit()
                .putInt("m_" + key, now)
                .putInt("d_" + day, today)
                .putInt(K_LAST_ML, 0)
                .putString(K_LOG, log.isEmpty() ? line : log + "\n" + line)
                .apply();
        BeerWidgetProvider.updateAll(c);
        return true;
    }

    /** Imposta a mano il totale di un mese (per inserire lo storico). */
    public static void setMonthMl(Context c, String key, int ml) {
        prefs(c).edit().putInt("m_" + key, Math.max(0, ml)).apply();
        BeerWidgetProvider.updateAll(c);
    }

    public static String getLog(Context c) {
        return prefs(c).getString(K_LOG, "");
    }

    /** Evita di contare due volte la stessa notifica (Wallet a volte la aggiorna). */
    public static boolean isDuplicate(Context c, String id) {
        SharedPreferences p = prefs(c);
        long now = System.currentTimeMillis();
        boolean dup = id.equals(p.getString(K_LAST_NOTIF, ""))
                && now - p.getLong(K_LAST_NOTIF_TIME, 0) < 10 * 60 * 1000L;
        if (!dup) {
            p.edit().putString(K_LAST_NOTIF, id).putLong(K_LAST_NOTIF_TIME, now).apply();
        }
        return dup;
    }

    // ---------- impostazioni ----------

    public static String getKeywords(Context c) {
        return prefs(c).getString(K_KEYWORDS, DEF_KEYWORDS);
    }

    public static float getThreshold(Context c) {
        return prefs(c).getFloat(K_THRESHOLD, DEF_THRESHOLD);
    }

    public static int getMlPerBeer(Context c) {
        return prefs(c).getInt(K_ML, DEF_ML);
    }

    public static boolean isWalletOnly(Context c) {
        return prefs(c).getBoolean(K_WALLET_ONLY, true);
    }

    public static int getGoalMonth(Context c) {
        return prefs(c).getInt(K_GOAL_MONTH, DEF_GOAL_MONTH);
    }

    public static int getGoalYear(Context c) {
        return prefs(c).getInt(K_GOAL_YEAR, DEF_GOAL_YEAR);
    }

    public static boolean isYearView(Context c) {
        return "anno".equals(prefs(c).getString(K_VIEW, "mese"));
    }

    public static void toggleView(Context c) {
        prefs(c).edit().putString(K_VIEW, isYearView(c) ? "mese" : "anno").apply();
    }

    public static float getKcalPer100(Context c) {
        return prefs(c).getFloat(K_KCAL, DEF_KCAL);
    }

    public static int kcal(Context c, int ml) {
        return Math.round(ml / 100f * getKcalPer100(c));
    }

    // ---------- stato del giorno ----------

    /** Stato scherzoso in base alle birre di oggi. Non è una misura del tasso alcolemico. */
    public static String[] mood(Context c) {
        int b = beers(c, getTodayMl(c));
        if (b <= 0) return new String[]{"😇", "Sobrio come un santo"};
        if (b == 1) return new String[]{"🙂", "Allegro"};
        if (b == 2) return new String[]{"😄", "Brillo"};
        if (b == 3) return new String[]{"🥴", "Alticcio"};
        if (b == 4) return new String[]{"🤪", "Cotto"};
        return new String[]{"🛋️", "Sciolto: acqua e divano!"};
    }

    /** Avviso guida: già dalla prima birra. */
    public static String driveWarning(Context c) {
        return getTodayMl(c) > 0 ? "🚗❌ Oggi niente guida" : "";
    }

    // ---------- formattazione ----------

    public static String liters(int ml) {
        return String.format(Locale.ITALY, "%.1f L", ml / 1000.0);
    }

    public static int beers(Context c, int ml) {
        int per = Math.max(1, getMlPerBeer(c));
        return (int) Math.floor(ml / (double) per);
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace(";", ",").replace("\n", " ").trim();
    }
}
